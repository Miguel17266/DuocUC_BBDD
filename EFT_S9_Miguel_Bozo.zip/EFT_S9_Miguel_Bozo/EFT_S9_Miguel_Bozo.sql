-- Tabla Academia
CREATE TABLE Academia (
    id_academia NUMBER(5) PRIMARY KEY,
    nombre_academia VARCHAR2(100) NOT NULL,
    cantidad_cursos NUMBER(3) NOT NULL,
    comuna VARCHAR2(100) NOT NULL
);

-- Tabla Municipalidad 
CREATE TABLE Municipalidad (
    id_municipalidad NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    id_academia NUMBER(10),
    CONSTRAINT PK_Municipalidad PRIMARY KEY (id_municipalidad),
    CONSTRAINT FK_Municipalidad_Academia FOREIGN KEY (id_academia) REFERENCES Academia(id_academia)
);

-- Tabla Colegio
CREATE TABLE Colegio (
    id_colegio NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    direccion VARCHAR2(150) NOT NULL,
    id_municipalidad NUMBER(10),
    CONSTRAINT PK_Colegio PRIMARY KEY (id_colegio),
    CONSTRAINT FK_Colegio_Municipalidad FOREIGN KEY (id_municipalidad) REFERENCES Municipalidad(id_municipalidad)
);

-- Tabla Formulario
CREATE TABLE Formulario (
    id_formulario NUMBER(10) NOT NULL,
    fecha_postulacion DATE NOT NULL,
    correo VARCHAR2(100) NOT NULL,
    id_academia NUMBER(10),
    CONSTRAINT PK_Formulario PRIMARY KEY (id_formulario),
    CONSTRAINT FK_Formulario_Academia FOREIGN KEY (id_academia) REFERENCES Academia(id_academia)
);

-- Tabla Proyecto Concursable
CREATE TABLE Proyecto_Concursable (
    id_proyecto NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    fecha_postulacion DATE NOT NULL,
    id_formulario NUMBER(10),
    CONSTRAINT PK_Proyecto PRIMARY KEY (id_proyecto),
    CONSTRAINT FK_Proyecto_Formulario FOREIGN KEY (id_formulario) REFERENCES Formulario(id_formulario)
);

-- Tabla Director 
CREATE TABLE Director (
    id_director NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    nacionalidad VARCHAR2(50) NOT NULL,
    id_academia NUMBER(10),
    CONSTRAINT PK_Director PRIMARY KEY (id_director),
    CONSTRAINT FK_Director_Academia FOREIGN KEY (id_academia) REFERENCES Academia(id_academia)
);

-- Tabla Tipo Academia
CREATE TABLE Tipo_Academia (
    id_tipo_academia NUMBER(10) NOT NULL,
    nombre_tipo VARCHAR2(100) NOT NULL,
    id_academia NUMBER(10),
    CONSTRAINT PK_Tipo_Academia PRIMARY KEY (id_tipo_academia),
    CONSTRAINT FK_Tipo_Academia_Academia FOREIGN KEY (id_academia) REFERENCES Academia(id_academia)
);

-- Tabla Profesor
CREATE TABLE Profesor (
    id_profesor NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    especialidad VARCHAR2(100) NOT NULL,
    id_tipo_academia NUMBER(10),
    CONSTRAINT PK_Profesor PRIMARY KEY (id_profesor),
    CONSTRAINT FK_Profesor_Tipo_Academia FOREIGN KEY (id_tipo_academia) REFERENCES Tipo_Academia(id_tipo_academia)
);

-- Tabla Turno
CREATE TABLE Turno (
    id_turno NUMBER(10) NOT NULL,
    dia VARCHAR2(50) NOT NULL,
    hora_inicio VARCHAR2(10) NOT NULL,
    hora_fin VARCHAR2(10) NOT NULL,
    id_profesor NUMBER(10),
    CONSTRAINT PK_Turno PRIMARY KEY (id_turno),
    CONSTRAINT FK_Turno_Profesor FOREIGN KEY (id_profesor) REFERENCES Profesor(id_profesor)
);

-- Tabla Instrumentos
CREATE TABLE Instrumentos (
    id_instrumento NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    id_tipo_academia NUMBER(10),
    CONSTRAINT PK_Instrumentos PRIMARY KEY (id_instrumento),
    CONSTRAINT FK_Instrumentos_Tipo_Academia FOREIGN KEY (id_tipo_academia) REFERENCES Tipo_Academia(id_tipo_academia)
);

-- Tabla Canto
CREATE TABLE Canto (
    id_canto NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    id_tipo_academia NUMBER(10),
    CONSTRAINT PK_Canto PRIMARY KEY (id_canto),
    CONSTRAINT FK_Canto_Tipo_Academia FOREIGN KEY (id_tipo_academia) REFERENCES Tipo_Academia(id_tipo_academia)
);

-- Tabla Danza
CREATE TABLE Danza (
    id_danza NUMBER(10) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    id_tipo_academia NUMBER(10),
    CONSTRAINT PK_Danza PRIMARY KEY (id_danza),
    CONSTRAINT FK_Danza_Tipo_Academia FOREIGN KEY (id_tipo_academia) REFERENCES Tipo_Academia(id_tipo_academia)
);

ALTER TABLE Colegio
DROP COLUMN direccion;

ALTER TABLE Colegio
ADD cantidad_estudiantes NUMBER(10);

ALTER TABLE Director
DROP COLUMN nacionalidad;

CREATE TABLE Turno (
    id_turno NUMBER(5) NOT NULL,
    tipo_turno VARCHAR2(50) NOT NULL,
    id_profesor NUMBER(5) NOT NULL,
    CONSTRAINT PK_Turno PRIMARY KEY (id_turno),
    CONSTRAINT FK_Turno_Profesor FOREIGN KEY (id_profesor) REFERENCES Profesor(id_profesor)
);


--Insertar Datos
--Insertar Academia
INSERT INTO Academia (id_academia, nombre_academia, cantidad_cursos, comuna)
VALUES (1, 'Academia de Danza Juvenil', 5, 'Las Condes');

INSERT INTO Academia (id_academia, nombre_academia, cantidad_cursos, comuna)
VALUES (2, 'Academia de Canto', 3, 'Nunoa');

INSERT INTO Academia (id_academia, nombre_academia, cantidad_cursos, comuna)
VALUES (3, 'Academia de Instrumentos Musicales', 4, 'Providencia');

--Insertar Municipalidad
INSERT INTO Municipalidad (id_municipalidad, nombre, id_academia)
VALUES (1, 'Las Condes', 1);

INSERT INTO Municipalidad (id_municipalidad, nombre, id_academia)
VALUES (2, 'Nunoa', 2);

INSERT INTO Municipalidad (id_municipalidad, nombre, id_academia)
VALUES (3, 'Providencia', 3);

--Tabla Colegio
INSERT INTO Colegio (id_colegio, nombre, cantidad_estudiantes, id_municipalidad)
VALUES (1, 'Colegio Las Condes', 20, 1);

INSERT INTO Colegio (id_colegio, nombre, cantidad_estudiantes, id_municipalidad)
VALUES (2, 'Colegio Nunoa', 30, 2);

INSERT INTO Colegio (id_colegio, nombre, cantidad_estudiantes, id_municipalidad)
VALUES (3, 'Colegio Providencia', 25, 3);

--Tabla Formulario
INSERT INTO Formulario (id_formulario, fecha_postulacion, correo, id_academia)
VALUES (1, TO_DATE('15/08/2023', 'DD/MM/YYYY'), 'info@danza.cl', 1);

INSERT INTO Formulario (id_formulario, fecha_postulacion, correo, id_academia)
VALUES (2, TO_DATE('20/09/2023', 'DD/MM/YYYY'), 'info@canto.cl', 2);

INSERT INTO Formulario (id_formulario, fecha_postulacion, correo, id_academia)
VALUES (3, TO_DATE('25/10/2023', 'DD/MM/YYYY'), 'info@instrumentos.cl', 3);

--Tabla Proyecto Concursable
INSERT INTO Proyecto_Concursable (id_proyecto, nombre, fecha_postulacion, id_formulario)
VALUES (1, 'Fomento a la Danza', TO_DATE('30/08/2023', 'DD/MM/YYYY'), 1);

INSERT INTO Proyecto_Concursable (id_proyecto, nombre, fecha_postulacion, id_formulario)
VALUES (2, 'Promoción del Canto', TO_DATE('10/09/2023', 'DD/MM/YYYY'), 2);

INSERT INTO Proyecto_Concursable (id_proyecto, nombre, fecha_postulacion, id_formulario)
VALUES (3, 'Iniciación en Instrumentos Musicales', TO_DATE('15/10/2023', 'DD/MM/YYYY'), 3);

--Tabla Tipo Academia
INSERT INTO Tipo_Academia (id_tipo_academia, nombre_tipo, id_academia)
VALUES (1, 'Danza Moderna', 1);

INSERT INTO Tipo_Academia (id_tipo_academia, nombre_tipo, id_academia)
VALUES (2, 'Canto Lírico', 2);

INSERT INTO Tipo_Academia (id_tipo_academia, nombre_tipo, id_academia)
VALUES (3, 'Instrumentos de Cuerda', 3);

--Tabla Instrumentos
INSERT INTO Instrumentos (id_instrumento, nombre, id_tipo_academia)
VALUES (1, 'Violín', 3);

INSERT INTO Instrumentos (id_instrumento, nombre, id_tipo_academia)
VALUES (2, 'Guitarra', 3);

INSERT INTO Instrumentos (id_instrumento, nombre, id_tipo_academia)
VALUES (3, 'Contrabajo', 3);

--Tabla Canto
INSERT INTO Canto (id_canto, nombre, id_tipo_academia)
VALUES (1, 'Canto Coral', 2);

INSERT INTO Canto (id_canto, nombre, id_tipo_academia)
VALUES (2, 'Canto Popular', 2);

INSERT INTO Canto (id_canto, nombre, id_tipo_academia)
VALUES (3, 'Canto Clasico', 2);


-- Tabla Danza
INSERT INTO Danza (id_danza, nombre, id_tipo_academia)
VALUES (1, 'Ballet Clásico', 1);

INSERT INTO Danza (id_danza, nombre, id_tipo_academia)
VALUES (2, 'Danza Contemporánea', 1);

INSERT INTO Danza (id_danza, nombre, id_tipo_academia)
VALUES (3, 'Danzas Folclóricas', 1);

--Tabla Profesor
INSERT INTO Profesor (id_profesor, nombre, especialidad, id_tipo_academia)
VALUES (1, 'María López', 'Canto', 2);

INSERT INTO Profesor (id_profesor, nombre, especialidad, id_tipo_academia)
VALUES (2, 'Juan Pérez', 'Danza Clásica', 1);

INSERT INTO Profesor (id_profesor, nombre, especialidad, id_tipo_academia)
VALUES (3, 'Pedro González', 'Instrumentos de Cuerda', 3);

--Tabla Turno
INSERT INTO Turno (id_turno, tipo_turno, id_profesor)
VALUES (1, 'Mañana', 1);

INSERT INTO Turno (id_turno, tipo_turno, id_profesor)
VALUES (2, 'Tarde', 2);

INSERT INTO Turno (id_turno, tipo_turno, id_profesor)
VALUES (3, 'Mañana y Tarde', 3);

-- Tabla Director
INSERT INTO Director (id_director, nombre, id_academia)
VALUES (1, 'Juan Pérez', 1);

INSERT INTO Director (id_director, nombre, id_academia)
VALUES (2, 'María González', 2);

INSERT INTO Director (id_director, nombre, id_academia)
VALUES (3, 'Carla Fernández', 3);

--Consultas

--Nombre de las Academias
SELECT nombre_academia 
FROM Academia;

--Especialidad de Profesores
SELECT nombre, especialidad 
FROM Profesor;

--Academia y municipalidad
SELECT A.nombre_academia, M.nombre 
FROM Academia A
JOIN Municipalidad M ON A.id_academia = M.id_academia;



